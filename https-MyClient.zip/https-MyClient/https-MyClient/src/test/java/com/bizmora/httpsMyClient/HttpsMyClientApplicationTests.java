package com.bizmora.httpsMyClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpsMyClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
